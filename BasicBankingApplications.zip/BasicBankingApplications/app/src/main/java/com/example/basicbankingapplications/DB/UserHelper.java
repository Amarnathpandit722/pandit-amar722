package com.example.basicbankingapplications.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.basicbankingapplications.DB.UserContract.UserEntry;
import com.example.basicbankingapplications.Data.User;

public class UserHelper extends SQLiteOpenHelper {

    String TABLE_NAME = UserEntry.TABLE_NAME;


    private static final String DATABASE_NAME = "User.db";


    private static final int DATABASE_VERSION = 1;

    public UserHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create a String that contains the SQL statement to create the pets table
        String SQL_CREATE_USER_TABLE =  "CREATE TABLE " + UserEntry.TABLE_NAME + " ("
                + UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " INTEGER, "
                + UserEntry.COLUMN_USER_NAME + " VARCHAR, "
                + UserEntry.COLUMN_USER_EMAIL + " VARCHAR, "
                + UserEntry.COLUMN_USER_IFSC_CODE + " VARCHAR, "
                + UserEntry.COLUMN_USER_PHONE_NO + " VARCHAR, "
                + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " INTEGER NOT NULL);";

        // Execute the SQL statement
        db.execSQL(SQL_CREATE_USER_TABLE);

        // Insert Into Table
        db.execSQL("insert into " + TABLE_NAME + " values(33423 ,'Amarnath','amar123@gmail.com','ABC10001','7895641238',15066)");
        db.execSQL("insert into " + TABLE_NAME + " values(33534 ,'Komal Kumari','komal189@gmail.com','VFS0001','5495454633',10345)");
        db.execSQL("insert into " + TABLE_NAME + " values(46436 ,'Aryan Dev','aran873@gmail.com','KFJ0453','78245233856',18530)");
        db.execSQL("insert into " + TABLE_NAME + " values(98091 ,'Suryadev Rajput','surya453@gmail.com','GAF5423','9489533128',28953)");
        db.execSQL("insert into " + TABLE_NAME + " values(74107,'Shivani Kumari', 'shivani@gmail.com','RTA3669','9095648962', 75808)");

        db.execSQL("insert into " + TABLE_NAME + " values(33535,'Gauri Joshi', 'gauri21@gmail.com','TEQ9455','8834640238', 66500)");
        db.execSQL("insert into " + TABLE_NAME + " values(79656,'Suresh Pratap', 'suresh876@gmail.com','YTU7695','7565463153', 48500)");
        db.execSQL("insert into " + TABLE_NAME + " values(97855,'Khushi Jain', 'khushi@gmail.com','UYT4522','9985021539', 25400)");
        db.execSQL("insert into " + TABLE_NAME + " values(78629,'Ritik Sharma', 'ritik@gmail.com','TRV6582','9309565238', 10507)");

        db.execSQL("insert into " + TABLE_NAME + " values(23659,'Rohit Patidar', 'rohit@gmail.com','NMH5450','8292591201', 99803)");
        db.execSQL("insert into " + TABLE_NAME + "  values(33424 ,'Shivani Kumari','shivi346@gmail.com','TYA10001','79028233423',56487)");
        db.execSQL("insert into " + TABLE_NAME + " values(65125 ,'Deepika Kumari','deep345@gmail.com','ERT46435','8792423344',26743)");
        db.execSQL("insert into " + TABLE_NAME + " values(11221,'Naveen Chaturvedi', 'naveen@gmail.com','JUK5566','9119541001', 58010)");

        db.execSQL("insert into " + TABLE_NAME + " values(98097 ,'Shahdev Kumar','shah898@gmail.com','GAF5423','87242343442',56467)");
        db.execSQL("insert into " + TABLE_NAME + " values(54636 ,'Pallavi Mondal','palavi756@gmail.com','KHG56908','8779535454',12023)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + UserEntry.TABLE_NAME);
            onCreate(db);
        }
    }

    public Cursor readAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME, null);
        return cursor;
    }

    public Cursor readParticularData (int accountNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME + " where " +
                                        UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo, null);
        return cursor;
    }

    public void updateAmount(int accountNo, int amount) {
        Log.d ("TAG", "update Amount");
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("update " + UserEntry.TABLE_NAME + " set " + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " = " + amount + " where " +
                UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo);
    }
}